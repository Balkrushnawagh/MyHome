package com.capgemini;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class EmployeeAdder {

	private static List<Employee>listOfEmp = new ArrayList<>();
	private static long employeeCount = 0;
	private static Employee employee;
	
	
	public static void main(String[] args) throws ParseException {
	
		Scanner sc = new Scanner(System.in);
		
		
		do {
			
			System.out.println("Please select the option");
			System.out.println("1. Add Employee");
			System.out.println("2. Show Employees");
			System.out.println("0. Exit");
			
			int option = sc.nextInt();

			
			switch(option) {
			
			 case 1 : addEmployee();
			 break;
			
			 case 2 : showEmployees();
			 break;
			 
			 case 0 : System.exit(0);;
				
			}
			
			
		
			
			
		} while(true);
		
		
		

	}
	
	private static void addEmployee() throws ParseException {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Please Enter UserName");
		String name = sc1.nextLine();
		
		System.out.println("Please Enter Date of joining in dd/mm/yyyy format");
		String date = sc1.nextLine();
		DateFormat dateFormate = new SimpleDateFormat("dd/mm/yyyy");
		Date joiningDate = dateFormate.parse(date);
		
		System.out.println("Please Enter User Type");
		System.out.println("a. Permanent");
		System.out.println("b. Contract");
		String type = sc1.nextLine();
		
		if (type.equalsIgnoreCase("b")) {
			
			System.out.println("Please ContractorsName");
			String contractorName = sc1.nextLine();
			
			System.out.println("Please Enter salaryPerHour");
			int salaryPerHour = sc1.nextInt();
			employee = new ContractBasedEmployee(name, EmployeeType.valueOf("CONTRACT"), joiningDate, contractorName, 0l, 0, salaryPerHour, employeeCount);
			
			
		} else {
			
			System.out.println("Please Enter salary");
			int salary = sc1.nextInt();
			
			employee = new PermanantEmployee(name, EmployeeType.valueOf("PERMANENT"), joiningDate, salary, employeeCount);
		}
		
//		sc1.close();
		employeeCount++;
		
		listOfEmp.add(employee);
		
	}
	
	private static void showEmployees() {
		
		for(Employee emp : listOfEmp) {
			System.out.println(emp);
		}
		
	}

	public List<Employee> getListOfEmp() {
		return listOfEmp;
	}

	public void setListOfEmp(List<Employee> listOfEmp) {
		this.listOfEmp = listOfEmp;
	}

	public long getEmployeeCount() {
		return employeeCount;
	}

	public void setEmployeeCount(long employeeCount) {
		this.employeeCount = employeeCount;
	}

}
