package com.capgemini;

import java.util.Date;

public abstract class Employee {
	public Employee(String name,Enum<EmployeeType> type,Date joiningDate, long salary) {
		
		this.name = name;
		this.type = type;
		this.joiningDate = joiningDate;
		this.salary = salary;
		
	}
	
	private final String organisationName = "Capgemini";
	
	private String name;
	private Enum<EmployeeType> type;
	private Date joiningDate;
	private long salary;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Enum<EmployeeType> getType() {
		return type;
	}
	public void setType(Enum<EmployeeType> type) {
		this.type = type;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public String getOrganisationName() {
		return organisationName;
	}
	
	
	
	
	
	

}
