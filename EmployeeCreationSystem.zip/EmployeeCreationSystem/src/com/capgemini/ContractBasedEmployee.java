package com.capgemini;

import java.util.Date;

public class ContractBasedEmployee extends Employee {
	
	public ContractBasedEmployee(String name,EmployeeType emplType,Date joiningDate, String contractorName,long salary, int workHours, int salaryPerHour, long id) {
		super(name,emplType,joiningDate,0,id);
		this.contractorName = contractorName;
		this.workHours = workHours;
		this.salaryPerHour = salaryPerHour;
	}
	
	private String contractorName;
	private int workHours;
	private int salaryPerHour;

	
	public String getContractorName() {
		return contractorName;
	}
	public void setContractorName(String contractorName) {
		this.contractorName = contractorName;
	}
	public int getWorkHours() {
		return workHours;
	}
	public void setWorkHours(int workHours) {
		this.workHours = workHours;
	}
	public int getSalaryPerHour() {
		return salaryPerHour;
	}
	public void setSalaryPerHour(int salaryPerHour) {
		this.salaryPerHour = salaryPerHour;
	}
	
	public long getSalary() {
		return workHours*salaryPerHour;
	}
	
	@Override
	public String toString() {
		return "ContractBasedEmployee [contractorName=" + contractorName + ", workHours=" + workHours
				+ ", salaryPerHour=" + salaryPerHour + ", id=" + getId() +" -- Name ="+super.getName()+" -- Type ="+super.getType()+" "
						+ "-- Date Of Joining ="+super.getJoiningDate()+" -- Salary ="+super.getSalary()+"]";
	}
	

}
