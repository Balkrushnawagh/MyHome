package com.capgemini;

import java.util.Date;

public class ContractBasedEmployee extends Employee {
	
	public ContractBasedEmployee(String name,EmployeeType emplType,Date joiningDate, String contractorName,long salary, int workHours, int salaryPerHour, long id) {
		super(name,emplType,joiningDate,0);
		this.contractorName = contractorName;
		this.workHours = workHours;
		this.salaryPerHour = salaryPerHour;
		this.id = id;
	}
	
	private String contractorName;
	private int workHours;
	private int salaryPerHour;
	private long id;
	
	public String getContractorName() {
		return contractorName;
	}
	public void setContractorName(String contractorName) {
		this.contractorName = contractorName;
	}
	public int getWorkHours() {
		return workHours;
	}
	public void setWorkHours(int workHours) {
		this.workHours = workHours;
	}
	public int getSalaryPerHour() {
		return salaryPerHour;
	}
	public void setSalaryPerHour(int salaryPerHour) {
		this.salaryPerHour = salaryPerHour;
	}
	public long getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public long getSalary() {
		return workHours*salaryPerHour;
	}
	
	@Override
	public String toString() {
		return "ContractBasedEmployee [contractorName=" + contractorName + ", workHours=" + workHours
				+ ", salaryPerHour=" + salaryPerHour + ", id=" + id +" -- Name ="+super.getName()+" -- Type ="+super.getType()+" "
						+ "-- Date Of Joining ="+super.getJoiningDate()+" -- Salary ="+super.getSalary()+"]";
	}
	

}
