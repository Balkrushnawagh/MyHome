package com.capgemini;

public enum EmployeeType {

	CONTRACT,PERMANENT;
	
}
