package com.capgemini;

import java.util.Date;

public class PermanantEmployee extends Employee {
	
	public PermanantEmployee(String name,Enum<EmployeeType> emplType,Date joiningDate,long salary, long id) {
		super(name,emplType,joiningDate,salary);
		this.id = id;
		
	}
	
	private long id;

	
	public long getId() {
		return id;
	}

	@Override
	public String toString() {
		return "PermanantEmployee [id =" + id +" -- Name ="+super.getName()+" -- Type ="+super.getType()+" "
				+ "-- Date Of Joining ="+super.getJoiningDate()+" -- Salary ="+super.getSalary()+"]";
	}

	public void setId(int id) {
		this.id = id;
	}

}
