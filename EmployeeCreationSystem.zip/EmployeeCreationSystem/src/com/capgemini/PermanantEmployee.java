package com.capgemini;

import java.util.Date;

public class PermanantEmployee extends Employee {
	
	public PermanantEmployee(String name,Enum<EmployeeType> emplType,Date joiningDate,long salary, long id) {
		super(name,emplType,joiningDate,salary,id);
		
	}
	

	@Override
	public String toString() {
		return "PermanantEmployee [id =" + super.getId() +" -- Name ="+super.getName()+" -- Type ="+super.getType()+" "
				+ "-- Date Of Joining ="+super.getJoiningDate()+" -- Salary ="+super.getSalary()+"]";
	}


}
